function navbar(){
    return `
    <h3><a href="index.html">Home</a></h3>
    <h3>Checkout these amazing Electronics gadgets 👇</h3>
    <div id="options">


        <h3>login</h3>
        <h3>signup</h3>
    </div>
    `;

}

export default navbar()